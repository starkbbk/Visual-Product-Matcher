import { colorDistance } from './color'
import type { Product } from './products'
export function computeSimilarityScore(queryHex:string, product:Product){const dist=colorDistance(queryHex,product.colorHex);const score=Math.max(0,100-(dist/4.42));return Math.round(score*10)/10}