import { create } from 'zustand'
import type { Product } from '../lib/products'
import products from '../data/products.json'
type Filters={category:string[],brands:string[],price:[number,number],rating:number,inStockOnly:boolean,colorHex?:string,similarityMin:number,sortBy:'similarity'|'price-asc'|'price-desc'|'rating'}
type State={products:Product[],queryColor?:string,filters:Filters,wishlist:string[],compare:string[],setQueryColor:(h?:string)=>void,setFilters:(f:Partial<Filters>)=>void,toggleWishlist:(id:string)=>void,toggleCompare:(id:string)=>void,resetFilters:()=>void}
const allBrands=Array.from(new Set(products.map(p=>p.brand))).sort()
const priceMax=Math.ceil(Math.max(...products.map(p=>p.price)))
const defaultFilters:Filters={category:[],brands:[],price:[0,priceMax],rating:0,inStockOnly:false,similarityMin:0,sortBy:'similarity'}
export const useStore=create<State>((set,get)=>({
  products,queryColor:undefined,filters:defaultFilters,wishlist:[],compare:[],
  setQueryColor:(hex)=>set({queryColor:hex}),
  setFilters:(f)=>set({filters:{...get().filters,...f}}),
  toggleWishlist:(id)=>set(s=>({wishlist:s.wishlist.includes(id)?s.wishlist.filter(x=>x!==id):[...s.wishlist,id]})),
  toggleCompare:(id)=>set(s=>{const exists=s.compare.includes(id);if(exists)return{compare:s.compare.filter(x=>x!==id)};if(s.compare.length>=3)return s;return{compare:[...s.compare,id]}}),
  resetFilters:()=>set({filters:defaultFilters})
}))
export { allBrands, priceMax }